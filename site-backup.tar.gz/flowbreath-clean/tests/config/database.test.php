<?php

declare(strict_types=1);

return [
    'host' => 'localhost',
    'dbname' => 'flowbreath_test',
    'username' => 'test_user',
    'password' => 'test_password',
    'charset' => 'utf8mb4'
]; 