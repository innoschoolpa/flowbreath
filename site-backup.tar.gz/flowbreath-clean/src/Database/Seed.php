<?php

namespace App\Database;

abstract class Seed {
    // ... existing code ...
} 