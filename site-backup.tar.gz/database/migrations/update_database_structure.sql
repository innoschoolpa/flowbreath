-- 트랜잭션 시작
START TRANSACTION;

-- 백업 테이블 생성 (기존 데이터 보존)
CREATE TABLE resources_backup AS SELECT * FROM resources;

-- 1. 리소스 번역 테이블 생성
CREATE TABLE resource_translations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    resource_id INT NOT NULL,
    language_code VARCHAR(5) NOT NULL,
    title VARCHAR(255) NOT NULL,
    content TEXT,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_resource_lang (resource_id, language_code),
    FOREIGN KEY (resource_id) REFERENCES resources(id) ON DELETE CASCADE,
    INDEX idx_language (language_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. 기존 리소스 데이터를 번역 테이블로 이전 (한국어 기본값)
INSERT INTO resource_translations (resource_id, language_code, title, content, description, created_at, updated_at)
SELECT id, 'ko', title, content, description, created_at, updated_at
FROM resources;

-- 3. resources 테이블에서 번역 관련 컬럼 제거
ALTER TABLE resources
    DROP COLUMN title,
    DROP COLUMN content,
    DROP COLUMN description,
    ADD like_count INT DEFAULT 0,
    ADD comment_count INT DEFAULT 0,
    ADD INDEX idx_view_count (view_count),
    ADD INDEX idx_popularity (view_count, like_count, comment_count),
    ADD INDEX idx_created_updated (created_at, updated_at),
    ADD INDEX idx_status_visibility (status, visibility);

-- 4. 태그 시스템 개선
ALTER TABLE tags
    ADD count INT DEFAULT 0,
    ADD deleted_at TIMESTAMP NULL,
    ADD INDEX idx_count (count);

-- 5. resource_tags 테이블 수정
ALTER TABLE resource_tags
    DROP COLUMN id,
    MODIFY created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    DROP COLUMN updated_at;

-- 6. 사용자 프로필 개선
ALTER TABLE users
    ADD profile_image VARCHAR(255) NULL,
    ADD bio TEXT NULL,
    ADD last_login_at TIMESTAMP NULL,
    ADD login_count INT DEFAULT 0,
    ADD last_password_change TIMESTAMP NULL,
    ADD failed_login_attempts INT DEFAULT 0,
    ADD locked_until TIMESTAMP NULL,
    ADD status ENUM('active', 'inactive', 'banned') DEFAULT 'active',
    ADD INDEX idx_status (status);

-- 7. 댓글 시스템 개선
ALTER TABLE comments
    ADD deleted_at TIMESTAMP NULL,
    ADD INDEX idx_created_at (created_at);

-- 8. 전문 검색 인덱스 추가
ALTER TABLE resource_translations
    ADD FULLTEXT INDEX ft_search (title, content, description);

-- 9. 태그 사용 횟수 업데이트
UPDATE tags t
SET count = (
    SELECT COUNT(*)
    FROM resource_tags rt
    WHERE rt.tag_id = t.id
);

-- 10. 리소스 통계 업데이트
UPDATE resources r
SET 
    like_count = (SELECT COUNT(*) FROM likes WHERE resource_id = r.id),
    comment_count = (SELECT COUNT(*) FROM comments WHERE resource_id = r.id AND is_deleted = 0);

-- 트랜잭션 커밋
COMMIT;

-- 롤백을 위한 복원 쿼리 (문제 발생 시 사용)
-- START TRANSACTION;
-- DROP TABLE resource_translations;
-- DROP TABLE resources;
-- RENAME TABLE resources_backup TO resources;
-- COMMIT; 