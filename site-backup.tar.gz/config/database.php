<?php

$config = [
    'driver' => 'mysql',
    'host' => getenv('DB_HOST') ?: 'srv636.hstgr.io',
    'port' => getenv('DB_PORT') ?: '3306',
    'database' => getenv('DB_DATABASE') ?: 'u573434051_flowbreath',
    'username' => getenv('DB_USERNAME') ?: 'u573434051_flow',
    'password' => getenv('DB_PASSWORD') ?: 'Eduispa1712!',
    'charset' => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci',
    'prefix' => '',
    'strict' => true,
    'engine' => null,
    
    // 보안 설정 추가
    'max_login_attempts' => 5,        // 최대 로그인 시도 횟수
    'login_lockout_time' => 900,      // 로그인 잠금 시간 (15분)
    'password_min_length' => 8,       // 최소 비밀번호 길이
    'require_special_chars' => true,  // 특수문자 요구
    'require_numbers' => true,        // 숫자 요구
    'require_uppercase' => true,      // 대문자 요구
    
    // 연결 풀 설정 - 극단적인 최적화
    'max_pool_size' => 1,         // 단일 연결만 사용
    'min_pool_size' => 1,         // 최소 연결 수 유지
    'connection_timeout' => 30,    // 연결 타임아웃 감소 (30초)
    'pool_check_interval' => 5,    // 풀 정리 주기 감소 (5초)
    
    // 쿼리 캐시 설정 - 캐시 비활성화
    'query_cache_enabled' => false, // 캐시 비활성화
    'query_cache_time' => 0,       // 캐시 시간 0
    'query_cache_size' => 0,       // 캐시 크기 0
    'cache_prefix' => '',          // 캐시 접두사 제거
    'cache_compression' => false,  // 캐시 압축 비활성화
    'cache_ttl' => 0,             // 캐시 TTL 0
    
    // 추가 최적화 설정
    'max_connections_per_hour' => 500,  // 시간당 최대 연결 수 증가
    'max_connections_per_minute' => 10,  // 분당 최대 연결 수 증가
    'connection_idle_timeout' => 30,    // 유휴 연결 타임아웃 증가 (30초)
    'persistent_connections' => true,   // 영구 연결 활성화
    
    // 성능 최적화 설정
    'enable_query_logging' => false,    // 쿼리 로깅 비활성화
    'enable_slow_query_log' => false,   // 슬로우 쿼리 로깅 비활성화
    'enable_prepared_statements' => true, // 준비된 구문 활성화 (보안 강화)
    'enable_statement_cache' => false,    // 구문 캐시 비활성화
    'statement_cache_size' => 0,         // 구문 캐시 크기 0
    'enable_connection_pooling' => false,  // 연결 풀링 비활성화
    'pool_reuse_threshold' => 0,         // 연결 재사용 비활성화
    'force_cache' => false,              // 강제 캐시 비활성화
    'cache_all_queries' => false,        // 쿼리 캐시 비활성화
];

class DatabaseConnection {
    private static $instance = null;
    private static $connection = null;
    private static $lastUsed = 0;
    private static $connectionCount = 0;
    private static $config = null;
    private static $logFile = __DIR__ . '/db_connection.log';
    private static $lastConnectionAttempt = 0;
    private static $connectionCooldown = 1; // 1 second cooldown between connection attempts
    private static $maxRetries = 3;
    private static $retryDelay = 1; // 1 second delay between retries
    
    private function __construct() {}
    
    private static function log($message) {
        $timestamp = date('Y-m-d H:i:s');
        $logMessage = "[$timestamp] $message\n";
        error_log($logMessage, 3, self::$logFile);
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
            self::log("New DatabaseConnection instance created");
        }
        return self::$instance;
    }
    
    private static function waitForCooldown() {
        $currentTime = microtime(true);
        $timeSinceLastAttempt = $currentTime - self::$lastConnectionAttempt;
        
        if ($timeSinceLastAttempt < self::$connectionCooldown) {
            $sleepTime = self::$connectionCooldown - $timeSinceLastAttempt;
            self::log("Waiting for connection cooldown: " . round($sleepTime, 2) . " seconds");
            usleep($sleepTime * 1000000); // Convert to microseconds
        }
        
        self::$lastConnectionAttempt = microtime(true);
    }
    
    public function getConnection() {
        global $config;
        self::$config = $config;
        
        $currentTime = time();
        
        // Reset connection count every hour
        if ($currentTime - self::$lastUsed >= 3600) {
            self::log("Resetting connection count. Previous count: " . self::$connectionCount);
            self::$connectionCount = 0;
            self::$lastUsed = $currentTime;
        }
        
        // Check if we've exceeded the hourly limit
        if (self::$connectionCount >= self::$config['max_connections_per_hour']) {
            self::log("Connection limit reached. Current count: " . self::$connectionCount);
            
            // Try to reuse existing connection with retries
            for ($retry = 0; $retry < self::$maxRetries; $retry++) {
                if (self::$connection !== null) {
                    try {
                        self::waitForCooldown();
                        self::$connection->query('SELECT 1');
                        self::log("Successfully reused existing connection after " . ($retry + 1) . " attempts");
                        return self::$connection;
                    } catch (PDOException $e) {
                        self::log("Failed to reuse connection (attempt " . ($retry + 1) . "): " . $e->getMessage());
                        self::$connection = null;
                        if ($retry < self::$maxRetries - 1) {
                            sleep(self::$retryDelay);
                        }
                    }
                }
            }
            
            throw new \Exception("Hourly connection limit reached. Please try again later.");
        }
        
        // Reuse existing connection if valid
        if (self::$connection !== null) {
            try {
                self::waitForCooldown();
                self::$connection->query('SELECT 1');
                self::log("Reusing existing connection");
                return self::$connection;
            } catch (PDOException $e) {
                self::log("Existing connection invalid: " . $e->getMessage());
                self::$connection = null;
            }
        }
        
        // Create new connection if needed
        try {
            self::waitForCooldown();
            self::log("Creating new connection. Current count: " . self::$connectionCount);
            
            $dsn = sprintf(
                "%s:host=%s;port=%s;dbname=%s;charset=%s",
                self::$config['driver'],
                self::$config['host'],
                self::$config['port'],
                self::$config['database'],
                self::$config['charset']
            );
            
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => true,
                PDO::ATTR_PERSISTENT => true,
                PDO::MYSQL_ATTR_USE_BUFFERED_QUERY => true,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
            ];
            
            self::$connection = new PDO($dsn, self::$config['username'], self::$config['password'], $options);
            self::$connectionCount++;
            self::$lastUsed = $currentTime;
            
            // Optimize connection settings
            self::$connection->exec("SET SESSION wait_timeout=" . self::$config['connection_timeout']);
            self::$connection->exec("SET SESSION interactive_timeout=" . self::$config['connection_timeout']);
            self::$connection->exec("SET SESSION sql_mode='STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'");
            
            self::log("New connection created successfully. Total connections: " . self::$connectionCount);
            return self::$connection;
        } catch (PDOException $e) {
            self::log("Failed to create new connection: " . $e->getMessage());
            error_log("Database connection failed: " . $e->getMessage());
            throw new \Exception("Database connection failed: " . $e->getMessage());
        }
    }
    
    public static function getConnectionCount() {
        return self::$connectionCount;
    }
    
    public static function resetConnection() {
        self::$connection = null;
        self::log("Connection reset requested");
    }
}

function getDbConnection() {
    return DatabaseConnection::getInstance()->getConnection();
}

return $config; 